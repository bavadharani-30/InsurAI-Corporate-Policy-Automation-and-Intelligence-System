import { pgTable, text, serial, integer, boolean, timestamp, varchar, date, time } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Import models from integrations
export * from "./models/auth";
export * from "./models/chat";

import { users } from "./models/auth";

// === ENUMS ===
export const userRoles = ["customer", "agent", "admin"] as const;
export const appointmentStatus = ["pending", "confirmed", "completed", "cancelled"] as const;

// === TABLES ===

// Extend users with role - we can't easily "extend" the table definition in Drizzle 
// without modifying the original file or using a separate profile table. 
// For simplicity in this stack, I will use a separate 'profiles' table or just assume 
// we can add columns if I could edit auth.ts. 
// Since I can't easily edit the integration file without potential issues during updates (conceptually), 
// I'll create a `user_roles` table or just add a profile table.
// ACTUALLY, the best way for this MVP is to create a 'profiles' table linked to 'users.id'.

export const profiles = pgTable("profiles", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  role: text("role", { enum: userRoles }).default("customer").notNull(),
  phoneNumber: text("phone_number"),
  specialization: text("specialization"), // For agents
  bio: text("bio"), // For agents
});

export const plans = pgTable("plans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  premium: integer("premium").notNull(), // stored in cents
  coverageAmount: integer("coverage_amount").notNull(),
  category: text("category").notNull(), // e.g., Health, Life, Corporate
  active: boolean("active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const agentAvailability = pgTable("agent_availability", {
  id: serial("id").primaryKey(),
  agentId: varchar("agent_id").notNull().references(() => users.id),
  dayOfWeek: integer("day_of_week").notNull(), // 0=Sunday, 1=Monday...
  startTime: text("start_time").notNull(), // HH:mm format
  endTime: text("end_time").notNull(), // HH:mm format
  isActive: boolean("is_active").default(true),
});

export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  customerId: varchar("customer_id").notNull().references(() => users.id),
  agentId: varchar("agent_id").notNull().references(() => users.id),
  planId: integer("plan_id").references(() => plans.id),
  date: date("date").notNull(), // YYYY-MM-DD
  time: text("time").notNull(), // HH:mm
  status: text("status", { enum: appointmentStatus }).default("pending").notNull(),
  notes: text("notes"),
  meetingLink: text("meeting_link"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  type: text("type").notNull(), // 'appointment_reminder', 'new_booking', 'cancellation'
  message: text("message").notNull(),
  read: boolean("read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// === RELATIONS ===
export const profilesRelations = relations(profiles, ({ one }) => ({
  user: one(users, {
    fields: [profiles.userId],
    references: [users.id],
  }),
}));

export const usersRelations = relations(users, ({ one, many }) => ({
  profile: one(profiles, {
    fields: [users.id],
    references: [profiles.userId],
  }),
  customerAppointments: many(appointments, { relationName: "customerAppointments" }),
  agentAppointments: many(appointments, { relationName: "agentAppointments" }),
  availability: many(agentAvailability),
  notifications: many(notifications),
}));

export const appointmentsRelations = relations(appointments, ({ one }) => ({
  customer: one(users, {
    fields: [appointments.customerId],
    references: [users.id],
    relationName: "customerAppointments",
  }),
  agent: one(users, {
    fields: [appointments.agentId],
    references: [users.id],
    relationName: "agentAppointments",
  }),
  plan: one(plans, {
    fields: [appointments.planId],
    references: [plans.id],
  }),
}));

export const agentAvailabilityRelations = relations(agentAvailability, ({ one }) => ({
  agent: one(users, {
    fields: [agentAvailability.agentId],
    references: [users.id],
  }),
}));

// === ZOD SCHEMAS ===

export const insertProfileSchema = createInsertSchema(profiles).omit({ id: true });
export const insertPlanSchema = createInsertSchema(plans).omit({ id: true, createdAt: true });
export const insertAvailabilitySchema = createInsertSchema(agentAvailability).omit({ id: true });
export const insertAppointmentSchema = createInsertSchema(appointments).omit({ id: true, createdAt: true, status: true });
export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, createdAt: true, read: true });

// === EXPLICIT API TYPES ===

export type Profile = typeof profiles.$inferSelect;
export type Plan = typeof plans.$inferSelect;
export type AgentAvailability = typeof agentAvailability.$inferSelect;
export type Appointment = typeof appointments.$inferSelect;
export type Notification = typeof notifications.$inferSelect;

export type InsertProfile = z.infer<typeof insertProfileSchema>;
export type InsertPlan = z.infer<typeof insertPlanSchema>;
export type InsertAvailability = z.infer<typeof insertAvailabilitySchema>;
export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;

// Request Types
export type CreatePlanRequest = InsertPlan;
export type UpdatePlanRequest = Partial<InsertPlan>;

export type SetAvailabilityRequest = InsertAvailability;
export type CreateAppointmentRequest = InsertAppointment;
export type UpdateAppointmentRequest = Partial<InsertAppointment> & { status?: typeof appointmentStatus[number] };

export type CreateProfileRequest = InsertProfile;
