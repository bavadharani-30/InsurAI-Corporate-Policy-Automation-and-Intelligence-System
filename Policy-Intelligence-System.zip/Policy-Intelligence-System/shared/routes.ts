import { z } from 'zod';
import { 
  insertPlanSchema, 
  insertAvailabilitySchema, 
  insertAppointmentSchema, 
  plans, 
  agentAvailability, 
  appointments,
  notifications,
  insertProfileSchema,
  profiles,
  userRoles,
  appointmentStatus,
  conversations,
  messages
} from './schema';
import { users } from './models/auth';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  })
};

export const api = {
  // === PROFILES ===
  profiles: {
    get: {
      method: 'GET' as const,
      path: '/api/profiles/:userId' as const,
      responses: {
        200: z.custom<typeof profiles.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/profiles/:userId' as const,
      input: insertProfileSchema.partial(),
      responses: {
        200: z.custom<typeof profiles.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    // Admin only: list all users/profiles
    list: {
      method: 'GET' as const,
      path: '/api/admin/users' as const,
      responses: {
        200: z.array(z.object({
          user: z.custom<typeof users.$inferSelect>(),
          profile: z.custom<typeof profiles.$inferSelect>().nullable(),
        })),
      }
    }
  },

  // === PLANS ===
  plans: {
    list: {
      method: 'GET' as const,
      path: '/api/plans' as const,
      responses: {
        200: z.array(z.custom<typeof plans.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/plans/:id' as const,
      responses: {
        200: z.custom<typeof plans.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/plans' as const,
      input: insertPlanSchema,
      responses: {
        201: z.custom<typeof plans.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/plans/:id' as const,
      input: insertPlanSchema.partial(),
      responses: {
        200: z.custom<typeof plans.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/plans/:id' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },

  // === APPOINTMENTS ===
  appointments: {
    // List appointments for the logged-in user (customer or agent)
    list: {
      method: 'GET' as const,
      path: '/api/appointments' as const,
      responses: {
        200: z.array(z.custom<typeof appointments.$inferSelect & { 
          agent?: typeof users.$inferSelect, 
          customer?: typeof users.$inferSelect,
          plan?: typeof plans.$inferSelect 
        }>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/appointments' as const,
      input: insertAppointmentSchema,
      responses: {
        201: z.custom<typeof appointments.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/appointments/:id' as const,
      input: insertAppointmentSchema.partial().extend({
        status: z.enum(appointmentStatus).optional(),
      }),
      responses: {
        200: z.custom<typeof appointments.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },

  // === AVAILABILITY ===
  availability: {
    list: {
      method: 'GET' as const,
      path: '/api/availability/:agentId' as const,
      responses: {
        200: z.array(z.custom<typeof agentAvailability.$inferSelect>()),
      },
    },
    update: {
      method: 'POST' as const,
      path: '/api/availability' as const,
      // Expects a full replacement list for simplicity
      input: z.object({
        availabilities: z.array(insertAvailabilitySchema.omit({ agentId: true }))
      }),
      responses: {
        200: z.array(z.custom<typeof agentAvailability.$inferSelect>()),
      },
    },
  },

  // === AGENTS ===
  agents: {
    list: {
      method: 'GET' as const,
      path: '/api/agents' as const,
      responses: {
        200: z.array(z.object({
          user: z.custom<typeof users.$inferSelect>(),
          profile: z.custom<typeof profiles.$inferSelect>().nullable(),
        })),
      },
    },
  },

  // === NOTIFICATIONS ===
  notifications: {
    list: {
      method: 'GET' as const,
      path: '/api/notifications' as const,
      responses: {
        200: z.array(z.custom<typeof notifications.$inferSelect>()),
      },
    },
    markRead: {
      method: 'PATCH' as const,
      path: '/api/notifications/:id/read' as const,
      responses: {
        200: z.custom<typeof notifications.$inferSelect>(),
      },
    },
  },

  // === CONVERSATIONS (AI Chat) ===
  conversations: {
    list: {
      method: 'GET' as const,
      path: '/api/conversations' as const,
      responses: {
        200: z.array(z.custom<typeof conversations.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/conversations/:id' as const,
      responses: {
        200: z.custom<typeof conversations.$inferSelect & { messages: typeof messages.$inferSelect[] }>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/conversations' as const,
      input: z.object({ title: z.string().optional() }),
      responses: {
        201: z.custom<typeof conversations.$inferSelect>(),
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/conversations/:id' as const,
      responses: {
        204: z.void(),
      },
    },
    // Voice/Audio Message
    sendMessage: {
      method: 'POST' as const,
      path: '/api/conversations/:id/messages' as const,
      input: z.object({ audio: z.string() }), // Base64 audio
      responses: {
        200: z.void(), // Returns SSE stream
      },
    }
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
