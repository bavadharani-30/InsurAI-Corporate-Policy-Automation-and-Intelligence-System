import { useAuth } from "@/hooks/use-auth";
import { useAppointments } from "@/hooks/use-appointments";
import { usePlans } from "@/hooks/use-plans";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, Plus, Shield, ArrowRight } from "lucide-react";
import { format } from "date-fns";
import { Link } from "wouter";

export default function CustomerDashboard() {
  const { user } = useAuth();
  const { data: appointments, isLoading: loadingAppointments } = useAppointments();
  const { data: plans, isLoading: loadingPlans } = usePlans();

  const nextAppointment = appointments?.find(a => a.status !== 'cancelled' && a.status !== 'completed');
  const myPlans = [1]; // Mock: in real app, fetch user's purchased plans

  return (
    <div className="space-y-8 animate-in">
      <div className="grid md:grid-cols-3 gap-6">
        {/* Welcome Card */}
        <Card className="col-span-2 p-8 bg-gradient-to-br from-primary to-blue-600 text-white border-0 shadow-xl rounded-3xl relative overflow-hidden">
           <div className="relative z-10">
              <h2 className="font-heading text-3xl font-bold mb-2">Welcome back, {user?.firstName}!</h2>
              <p className="text-blue-100 mb-6 max-w-md">Your insurance portfolio looks healthy. You have 2 active policies and 1 upcoming review.</p>
              <Link href="/book">
                <Button variant="secondary" className="shadow-lg hover:bg-white text-primary font-bold">
                   <Plus className="w-4 h-4 mr-2" /> Book New Appointment
                </Button>
              </Link>
           </div>
           <div className="absolute right-0 bottom-0 opacity-10 transform translate-x-1/4 translate-y-1/4">
              <Shield className="w-64 h-64" />
           </div>
        </Card>

        {/* Next Appointment Card */}
        <Card className="p-6 rounded-3xl border shadow-sm hover:shadow-md transition-all">
           <div className="flex items-center justify-between mb-4">
              <h3 className="font-heading font-bold text-lg">Next Meeting</h3>
              <div className="p-2 bg-blue-50 text-primary rounded-full">
                 <Calendar className="w-5 h-5" />
              </div>
           </div>
           {loadingAppointments ? (
             <div className="animate-pulse h-20 bg-muted rounded-xl" />
           ) : nextAppointment ? (
             <div className="space-y-3">
                <div className="flex items-center gap-3">
                   <div className="text-2xl font-bold font-heading">
                      {format(new Date(nextAppointment.date), "MMM d")}
                   </div>
                   <div className="h-8 w-[1px] bg-border" />
                   <div className="text-sm text-muted-foreground flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {nextAppointment.time}
                   </div>
                </div>
                <div className="p-3 bg-muted/50 rounded-xl">
                   <p className="font-medium text-sm">Review with {nextAppointment.agent?.firstName}</p>
                   <p className="text-xs text-muted-foreground mt-1">Video Consultation</p>
                </div>
             </div>
           ) : (
             <div className="text-center py-8 text-muted-foreground">
                <p>No upcoming meetings</p>
             </div>
           )}
        </Card>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
         {/* My Plans */}
         <section>
            <div className="flex items-center justify-between mb-4">
               <h3 className="font-heading font-bold text-xl">My Active Plans</h3>
               <Button variant="ghost" size="sm" className="text-primary">View All</Button>
            </div>
            <div className="grid gap-4">
               {loadingPlans ? (
                 <div className="h-32 bg-muted animate-pulse rounded-2xl" />
               ) : (
                 plans?.slice(0, 2).map((plan) => (
                   <div key={plan.id} className="group flex items-center justify-between p-5 bg-white border rounded-2xl shadow-sm hover:shadow-md hover:border-primary/50 transition-all">
                      <div className="flex items-center gap-4">
                         <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-colors">
                            <Shield className="w-6 h-6" />
                         </div>
                         <div>
                            <h4 className="font-bold">{plan.name}</h4>
                            <p className="text-sm text-muted-foreground">{plan.category}</p>
                         </div>
                      </div>
                      <div className="text-right">
                         <div className="font-bold">${(plan.premium / 100).toFixed(2)}/mo</div>
                         <div className="text-xs text-green-600 font-medium">Active</div>
                      </div>
                   </div>
                 ))
               )}
            </div>
         </section>
         
         {/* Recent Appointments */}
         <section>
            <div className="flex items-center justify-between mb-4">
               <h3 className="font-heading font-bold text-xl">Recent History</h3>
            </div>
            <div className="bg-white border rounded-2xl shadow-sm p-2">
               {appointments?.slice(0, 3).map((apt, i) => (
                  <div key={apt.id} className={`flex items-center justify-between p-4 ${i !== appointments.length - 1 ? 'border-b' : ''}`}>
                     <div className="flex items-center gap-4">
                        <div className="bg-muted w-10 h-10 rounded-full flex items-center justify-center text-xs font-bold text-muted-foreground">
                           {format(new Date(apt.date), "dd")}
                        </div>
                        <div>
                           <p className="font-medium text-sm">Meeting with {apt.agent?.firstName}</p>
                           <p className="text-xs text-muted-foreground capitalize">{apt.status}</p>
                        </div>
                     </div>
                     <Button variant="ghost" size="icon">
                        <ArrowRight className="w-4 h-4 text-muted-foreground" />
                     </Button>
                  </div>
               ))}
               {(!appointments || appointments.length === 0) && (
                 <div className="p-8 text-center text-muted-foreground">No history yet</div>
               )}
            </div>
         </section>
      </div>
    </div>
  );
}
