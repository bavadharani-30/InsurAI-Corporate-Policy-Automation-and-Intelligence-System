import { useAuth } from "@/hooks/use-auth";
import { usePlans, useDeletePlan } from "@/hooks/use-plans";
import { useAdminUsersList } from "@/hooks/use-profiles";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Trash2, Edit, Users, Shield } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

export default function AdminDashboard() {
  const { data: plans, isLoading: plansLoading } = usePlans();
  const { data: users, isLoading: usersLoading } = useAdminUsersList();
  const deletePlan = useDeletePlan();

  return (
    <div className="space-y-8 animate-in">
       <div>
          <h2 className="font-heading text-3xl font-bold">Admin Portal</h2>
          <p className="text-muted-foreground">System overview and management.</p>
       </div>

       <div className="grid md:grid-cols-2 gap-8">
          {/* Plans Management */}
          <Card className="border shadow-sm overflow-hidden">
             <div className="p-6 border-b flex justify-between items-center bg-gray-50/50">
                <div className="flex items-center gap-2">
                   <Shield className="w-5 h-5 text-primary" />
                   <h3 className="font-bold text-lg">Insurance Plans</h3>
                </div>
                <Button size="sm"><Plus className="w-4 h-4 mr-2" /> Add Plan</Button>
             </div>
             <div className="p-0">
                <Table>
                   <TableHeader>
                      <TableRow>
                         <TableHead>Name</TableHead>
                         <TableHead>Premium</TableHead>
                         <TableHead>Status</TableHead>
                         <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                   </TableHeader>
                   <TableBody>
                      {plansLoading ? (
                        <TableRow><TableCell colSpan={4}>Loading...</TableCell></TableRow>
                      ) : plans?.map(plan => (
                        <TableRow key={plan.id}>
                           <TableCell className="font-medium">{plan.name}</TableCell>
                           <TableCell>${(plan.premium / 100).toFixed(2)}</TableCell>
                           <TableCell>
                              <Badge variant={plan.active ? "default" : "secondary"}>
                                 {plan.active ? "Active" : "Inactive"}
                              </Badge>
                           </TableCell>
                           <TableCell className="text-right">
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                 <Edit className="w-4 h-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-8 w-8 text-destructive hover:text-destructive"
                                onClick={() => deletePlan.mutate(plan.id)}
                              >
                                 <Trash2 className="w-4 h-4" />
                              </Button>
                           </TableCell>
                        </TableRow>
                      ))}
                   </TableBody>
                </Table>
             </div>
          </Card>

          {/* Users Management */}
          <Card className="border shadow-sm overflow-hidden">
             <div className="p-6 border-b flex justify-between items-center bg-gray-50/50">
                <div className="flex items-center gap-2">
                   <Users className="w-5 h-5 text-blue-600" />
                   <h3 className="font-bold text-lg">User Management</h3>
                </div>
             </div>
             <div className="p-0">
                <Table>
                   <TableHeader>
                      <TableRow>
                         <TableHead>User</TableHead>
                         <TableHead>Role</TableHead>
                         <TableHead className="text-right">Joined</TableHead>
                      </TableRow>
                   </TableHeader>
                   <TableBody>
                      {usersLoading ? (
                        <TableRow><TableCell colSpan={3}>Loading...</TableCell></TableRow>
                      ) : users?.map(({ user, profile }) => (
                        <TableRow key={user.id}>
                           <TableCell>
                              <div className="flex flex-col">
                                 <span className="font-medium">{user.firstName} {user.lastName}</span>
                                 <span className="text-xs text-muted-foreground">{user.email}</span>
                              </div>
                           </TableCell>
                           <TableCell>
                              <Badge variant="outline" className="capitalize">
                                 {profile?.role || "Customer"}
                              </Badge>
                           </TableCell>
                           <TableCell className="text-right text-xs text-muted-foreground">
                              {new Date(user.createdAt || "").toLocaleDateString()}
                           </TableCell>
                        </TableRow>
                      ))}
                   </TableBody>
                </Table>
             </div>
          </Card>
       </div>
    </div>
  );
}
