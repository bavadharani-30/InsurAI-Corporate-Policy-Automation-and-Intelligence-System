import { useAuth } from "@/hooks/use-auth";
import { useAppointments } from "@/hooks/use-appointments";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar as CalendarIcon, Clock, Users, CheckCircle, XCircle } from "lucide-react";
import { format } from "date-fns";

export default function AgentDashboard() {
  const { user } = useAuth();
  const { data: appointments, isLoading } = useAppointments();

  const pending = appointments?.filter(a => a.status === 'pending') || [];
  const confirmed = appointments?.filter(a => a.status === 'confirmed') || [];

  return (
    <div className="space-y-8 animate-in">
       <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
             <h2 className="font-heading text-3xl font-bold">Agent Dashboard</h2>
             <p className="text-muted-foreground">Manage your schedule and client requests.</p>
          </div>
          <Button>Update Availability</Button>
       </div>

       <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: "Total Appointments", value: appointments?.length || 0, icon: CalendarIcon, color: "text-blue-500" },
            { label: "Pending Requests", value: pending.length, icon: Clock, color: "text-orange-500" },
            { label: "Confirmed", value: confirmed.length, icon: CheckCircle, color: "text-green-500" },
            { label: "Total Clients", value: new Set(appointments?.map(a => a.customerId)).size || 0, icon: Users, color: "text-purple-500" }
          ].map((stat, i) => (
            <Card key={i} className="p-6 border shadow-sm hover:shadow-md transition-all">
               <div className="flex items-center justify-between">
                  <div>
                     <p className="text-sm font-medium text-muted-foreground mb-1">{stat.label}</p>
                     <h3 className="text-3xl font-bold font-heading">{stat.value}</h3>
                  </div>
                  <div className={`p-3 bg-muted rounded-xl ${stat.color}`}>
                     <stat.icon className="w-6 h-6" />
                  </div>
               </div>
            </Card>
          ))}
       </div>

       <div className="grid lg:grid-cols-3 gap-8">
          <Card className="lg:col-span-2 border shadow-sm p-6">
             <h3 className="font-heading font-bold text-xl mb-6">Upcoming Schedule</h3>
             <div className="space-y-4">
                {isLoading ? (
                  <div className="h-48 bg-muted animate-pulse rounded-xl" />
                ) : appointments?.filter(a => a.status !== 'cancelled').map((apt) => (
                  <div key={apt.id} className="flex items-start gap-4 p-4 border rounded-xl hover:bg-muted/30 transition-colors">
                     <div className="flex flex-col items-center min-w-[60px] p-2 bg-blue-50 text-blue-600 rounded-lg">
                        <span className="text-xs font-bold uppercase">{format(new Date(apt.date), "MMM")}</span>
                        <span className="text-xl font-bold">{format(new Date(apt.date), "dd")}</span>
                     </div>
                     <div className="flex-1">
                        <div className="flex justify-between items-start">
                           <div>
                              <h4 className="font-bold text-foreground">Consultation with {apt.customer?.firstName} {apt.customer?.lastName}</h4>
                              <p className="text-sm text-muted-foreground mt-1">Topic: {apt.plan?.name || "General Inquiry"}</p>
                           </div>
                           <div className="px-3 py-1 bg-muted rounded-full text-xs font-medium capitalize">
                              {apt.status}
                           </div>
                        </div>
                        <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground">
                           <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {apt.time}</span>
                           <span>• Video Call</span>
                        </div>
                     </div>
                  </div>
                ))}
             </div>
          </Card>

          <Card className="border shadow-sm p-6 h-fit">
             <h3 className="font-heading font-bold text-xl mb-6">Pending Actions</h3>
             <div className="space-y-4">
                {pending.length === 0 ? (
                  <p className="text-muted-foreground text-sm">No pending requests.</p>
                ) : pending.map(apt => (
                  <div key={apt.id} className="p-4 bg-orange-50/50 border border-orange-100 rounded-xl">
                     <p className="font-bold text-sm mb-1">{apt.customer?.firstName} requested a meeting</p>
                     <p className="text-xs text-muted-foreground mb-3">
                        {format(new Date(apt.date), "MMM d")} at {apt.time}
                     </p>
                     <div className="flex gap-2">
                        <Button size="sm" className="w-full bg-green-600 hover:bg-green-700">Accept</Button>
                        <Button size="sm" variant="outline" className="w-full">Decline</Button>
                     </div>
                  </div>
                ))}
             </div>
          </Card>
       </div>
    </div>
  );
}
