import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Shield, Check, ArrowRight, Mic } from "lucide-react";
import { motion } from "framer-motion";

export default function LandingPage() {
  const { user, isLoading } = useAuth();

  if (isLoading) return <div className="min-h-screen bg-background" />;

  return (
    <div className="min-h-screen bg-background font-sans text-foreground overflow-hidden">
      {/* Navigation */}
      <nav className="fixed w-full z-50 bg-white/80 backdrop-blur-md border-b border-white/20">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2 font-heading font-bold text-2xl text-primary">
            <Shield className="w-8 h-8" />
            InsurAI
          </div>
          <div className="flex items-center gap-4">
            {user ? (
              <Link href="/dashboard">
                <Button>Go to Dashboard</Button>
              </Link>
            ) : (
              <a href="/api/login">
                <Button>Login</Button>
              </a>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 px-6">
         {/* Background Decoration */}
         <div className="absolute top-0 right-0 -z-10 w-[800px] h-[800px] bg-primary/5 rounded-full blur-3xl translate-x-1/3 -translate-y-1/4" />
         
         <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
               <h1 className="font-heading text-5xl lg:text-7xl font-bold leading-tight mb-6 text-foreground">
                 Insurance made <span className="text-primary">Intelligent</span>.
               </h1>
               <p className="text-lg text-muted-foreground mb-8 max-w-lg leading-relaxed">
                 Experience the future of insurance with AI-driven policy management, instant voice assistance, and seamless scheduling.
               </p>
               <div className="flex flex-col sm:flex-row gap-4">
                  <a href={user ? "/dashboard" : "/api/login"}>
                    <Button size="lg" className="h-14 px-8 text-lg rounded-xl shadow-xl shadow-primary/20 hover:shadow-2xl hover:scale-105 transition-all">
                       Get Started <ArrowRight className="ml-2 w-5 h-5" />
                    </Button>
                  </a>
                  <Button variant="outline" size="lg" className="h-14 px-8 text-lg rounded-xl">
                     View Demo
                  </Button>
               </div>
               
               <div className="mt-12 flex items-center gap-8 text-sm font-medium text-muted-foreground">
                  <div className="flex items-center gap-2">
                     <Check className="w-5 h-5 text-primary" /> No credit card required
                  </div>
                  <div className="flex items-center gap-2">
                     <Check className="w-5 h-5 text-primary" /> Free forever plan
                  </div>
               </div>
            </motion.div>

            <motion.div 
               initial={{ opacity: 0, scale: 0.95 }}
               animate={{ opacity: 1, scale: 1 }}
               transition={{ duration: 0.8, delay: 0.2 }}
               className="relative"
            >
               {/* Hero Image */}
               <div className="relative z-10 rounded-3xl overflow-hidden shadow-2xl border border-white/20 ring-1 ring-black/5">
                 {/* landing page hero corporate dashboard */}
                 <img 
                   src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1600&h=1200&fit=crop" 
                   alt="Dashboard Preview" 
                   className="w-full h-auto"
                 />
                 
                 {/* Floating Card Animation */}
                 <motion.div 
                    animate={{ y: [0, -10, 0] }}
                    transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                    className="absolute bottom-8 left-8 bg-white/90 backdrop-blur p-4 rounded-xl shadow-xl border max-w-xs"
                 >
                    <div className="flex items-center gap-3 mb-2">
                       <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-primary">
                          <Mic className="w-4 h-4" />
                       </div>
                       <div className="text-sm font-bold">AI Assistant</div>
                    </div>
                    <p className="text-xs text-muted-foreground">"I found 3 health plans that match your criteria. Would you like to compare them?"</p>
                 </motion.div>
               </div>
            </motion.div>
         </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 bg-secondary/50">
         <div className="max-w-7xl mx-auto px-6">
            <div className="text-center max-w-2xl mx-auto mb-16">
               <h2 className="font-heading text-3xl font-bold mb-4">Why Choose InsurAI?</h2>
               <p className="text-muted-foreground">We combine cutting-edge technology with trusted insurance expertise to give you the best protection.</p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
               {[
                 { title: "Smart Scheduling", desc: "Book appointments with agents instantly based on real-time availability.", icon: "📅" },
                 { title: "AI Assistance", desc: "Get instant answers to your policy questions via voice or text chat.", icon: "🤖" },
                 { title: "Tailored Plans", desc: "Our system recommends the best insurance plans for your specific needs.", icon: "🛡️" }
               ].map((feature, idx) => (
                 <div key={idx} className="bg-white p-8 rounded-2xl shadow-lg border hover:border-primary/50 transition-colors">
                    <div className="text-4xl mb-6">{feature.icon}</div>
                    <h3 className="font-heading text-xl font-bold mb-3">{feature.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{feature.desc}</p>
                 </div>
               ))}
            </div>
         </div>
      </section>
    </div>
  );
}
