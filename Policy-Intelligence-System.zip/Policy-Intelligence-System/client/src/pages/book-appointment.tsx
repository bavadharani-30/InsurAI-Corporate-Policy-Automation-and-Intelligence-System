import { useAuth } from "@/hooks/use-auth";
import { usePlans } from "@/hooks/use-plans";
import { useAgentsList } from "@/hooks/use-profiles";
import { useAvailability } from "@/hooks/use-availability";
import { useCreateAppointment } from "@/hooks/use-appointments";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { useState } from "react";
import { useLocation } from "wouter";
import { format } from "date-fns";
import { Loader2 } from "lucide-react";

export default function BookAppointment() {
  const [, setLocation] = useLocation();
  const { data: plans } = usePlans();
  const { data: agents } = useAgentsList();
  const createAppointment = useCreateAppointment();

  const [selectedPlan, setSelectedPlan] = useState<string>("");
  const [selectedAgent, setSelectedAgent] = useState<string>("");
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [time, setTime] = useState<string>("");

  const { data: availability } = useAvailability(selectedAgent);

  const handleSubmit = async () => {
    if (!selectedAgent || !date || !time) return;

    try {
      await createAppointment.mutateAsync({
         agentId: selectedAgent,
         planId: selectedPlan ? parseInt(selectedPlan) : undefined,
         date: format(date, "yyyy-MM-dd"),
         time,
         customerId: "temp-id-handled-by-backend", // Backend should infer from session
         notes: "Booked via portal"
      });
      setLocation("/dashboard");
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-in">
       <div className="text-center">
          <h1 className="font-heading text-3xl font-bold">Book a Consultation</h1>
          <p className="text-muted-foreground">Schedule time with an expert agent.</p>
       </div>

       <Card className="p-8 border shadow-lg space-y-8">
          {/* Step 1: Plan */}
          <div className="space-y-4">
             <h3 className="font-bold text-lg">1. Select a Topic (Optional)</h3>
             <Select value={selectedPlan} onValueChange={setSelectedPlan}>
               <SelectTrigger>
                 <SelectValue placeholder="Choose a plan to discuss..." />
               </SelectTrigger>
               <SelectContent>
                 {plans?.map(plan => (
                   <SelectItem key={plan.id} value={String(plan.id)}>{plan.name}</SelectItem>
                 ))}
               </SelectContent>
             </Select>
          </div>

          {/* Step 2: Agent */}
          <div className="space-y-4">
             <h3 className="font-bold text-lg">2. Choose an Agent</h3>
             <div className="grid sm:grid-cols-2 gap-4">
                {agents?.map(({ user, profile }) => (
                   <div 
                     key={user.id}
                     className={`p-4 border rounded-xl cursor-pointer transition-all ${selectedAgent === user.id ? 'border-primary bg-primary/5 ring-1 ring-primary' : 'hover:border-primary/50'}`}
                     onClick={() => setSelectedAgent(user.id)}
                   >
                      <div className="font-bold">{user.firstName} {user.lastName}</div>
                      <div className="text-sm text-muted-foreground">{profile?.specialization || "Insurance Expert"}</div>
                   </div>
                ))}
             </div>
          </div>

          {/* Step 3: Date & Time */}
          {selectedAgent && (
             <div className="space-y-4">
                <h3 className="font-bold text-lg">3. Select Time</h3>
                <div className="flex flex-col md:flex-row gap-8">
                   <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      className="rounded-md border shadow-sm p-4 w-fit"
                   />
                   <div className="flex-1">
                      <div className="grid grid-cols-2 gap-2">
                         {["09:00", "10:00", "11:00", "14:00", "15:00", "16:00"].map((t) => (
                            <Button 
                              key={t} 
                              variant={time === t ? "default" : "outline"}
                              onClick={() => setTime(t)}
                            >
                               {t}
                            </Button>
                         ))}
                      </div>
                   </div>
                </div>
             </div>
          )}

          <Button 
            size="lg" 
            className="w-full font-bold text-lg h-12" 
            disabled={!selectedAgent || !date || !time || createAppointment.isPending}
            onClick={handleSubmit}
          >
             {createAppointment.isPending ? <Loader2 className="animate-spin" /> : "Confirm Booking"}
          </Button>
       </Card>
    </div>
  );
}
