import { useAuth } from "@/hooks/use-auth";
import { VoiceAssistant } from "@/components/voice-assistant";
import { Button } from "@/components/ui/button";
import { ChevronLeft } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useEffect, useState } from "react";

export default function VoiceChatPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [conversationId, setConversationId] = useState<number | null>(null);

  // Auto-create conversation on mount
  const createConversation = useMutation({
    mutationFn: async () => {
      const res = await fetch(api.conversations.create.path, {
         method: "POST",
         headers: { "Content-Type": "application/json" },
         body: JSON.stringify({ title: "New Voice Chat" }),
         credentials: "include"
      });
      if (!res.ok) throw new Error("Failed");
      return await res.json();
    },
    onSuccess: (data) => setConversationId(data.id)
  });

  useEffect(() => {
     if (user && !conversationId) {
        createConversation.mutate();
     }
  }, [user]);

  if (!conversationId) return (
     <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center">
        <div className="animate-pulse text-primary font-bold">Initializing Assistant...</div>
     </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex flex-col items-center justify-center p-4">
       <div className="w-full max-w-lg space-y-4">
          <Link href="/dashboard">
             <Button variant="ghost" className="text-muted-foreground hover:text-primary">
                <ChevronLeft className="w-4 h-4 mr-2" /> Back to Dashboard
             </Button>
          </Link>
          
          <div className="text-center mb-8">
             <h1 className="font-heading text-3xl font-bold mb-2">How can I help you?</h1>
             <p className="text-muted-foreground">Ask about plans, coverage, or claims.</p>
          </div>

          <VoiceAssistant conversationId={conversationId} />
       </div>
    </div>
  );
}
