import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertAvailability } from "@shared/schema";

export function useAvailability(agentId: string | undefined) {
  return useQuery({
    queryKey: [api.availability.list.path, agentId],
    queryFn: async () => {
      if (!agentId) return [];
      const url = buildUrl(api.availability.list.path, { agentId });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch availability");
      return api.availability.list.responses[200].parse(await res.json());
    },
    enabled: !!agentId,
  });
}

export function useUpdateAvailability() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (availabilities: Omit<InsertAvailability, "agentId">[]) => {
      const res = await fetch(api.availability.update.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ availabilities }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update availability");
      return api.availability.update.responses[200].parse(await res.json());
    },
    onSuccess: (data, variables, context) => {
       // Ideally we'd know the agentId here to invalidate specifically, but list path is dynamic
       queryClient.invalidateQueries({ queryKey: [api.availability.list.path] });
    },
  });
}
