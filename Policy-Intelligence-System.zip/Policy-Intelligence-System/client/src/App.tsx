import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { useAuth } from "@/hooks/use-auth";
import { useProfile } from "@/hooks/use-profiles";
import { Layout } from "@/components/layout";
import { Loader2 } from "lucide-react";

import LandingPage from "@/pages/landing-page";
import CustomerDashboard from "@/pages/dashboard/customer-dashboard";
import AgentDashboard from "@/pages/dashboard/agent-dashboard";
import AdminDashboard from "@/pages/dashboard/admin-dashboard";
import VoiceChatPage from "@/pages/voice-chat-page";
import BookAppointment from "@/pages/book-appointment";
import NotFound from "@/pages/not-found";

function DashboardRouter() {
  const { user, isLoading: authLoading } = useAuth();
  const { data: profile, isLoading: profileLoading } = useProfile(user?.id);
  const [, setLocation] = useLocation();

  if (authLoading || profileLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    setLocation("/");
    return null;
  }

  const role = profile?.role || "customer";

  return (
    <Layout>
      <Switch>
        <Route path="/dashboard">
          {role === "admin" ? <AdminDashboard /> : 
           role === "agent" ? <AgentDashboard /> : 
           <CustomerDashboard />}
        </Route>
        
        {/* Specific Roles */}
        <Route path="/admin/*" component={role === "admin" ? AdminDashboard : NotFound} />
        
        {/* Shared features */}
        <Route path="/book" component={BookAppointment} />
        <Route path="/schedule" component={role === "agent" ? AgentDashboard : NotFound} />
        
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/voice-assistant" component={VoiceChatPage} />
      
      {/* All protected routes go through DashboardRouter which handles layout */}
      <Route path="/dashboard" component={DashboardRouter} />
      <Route path="/book" component={DashboardRouter} />
      <Route path="/admin/*" component={DashboardRouter} />
      <Route path="/schedule" component={DashboardRouter} />
      <Route path="/plans" component={DashboardRouter} />
      <Route path="/availability" component={DashboardRouter} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Toaster />
      <Router />
    </QueryClientProvider>
  );
}

export default App;
