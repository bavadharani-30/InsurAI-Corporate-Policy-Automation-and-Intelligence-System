import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useProfile } from "@/hooks/use-profiles";
import {
  LayoutDashboard,
  Calendar,
  Users,
  Shield,
  LogOut,
  Bell,
  Menu,
  X,
  Mic,
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const { data: profile } = useProfile(user?.id);
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  const role = profile?.role || "customer";

  const navItems = [
    { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    ...(role === "customer"
      ? [
          { label: "My Plans", href: "/plans", icon: Shield },
          { label: "Book Appointment", href: "/book", icon: Calendar },
        ]
      : []),
    ...(role === "agent"
      ? [
          { label: "Schedule", href: "/schedule", icon: Calendar },
          { label: "Availability", href: "/availability", icon: Users },
        ]
      : []),
    ...(role === "admin"
      ? [
          { label: "Manage Plans", href: "/admin/plans", icon: Shield },
          { label: "Manage Users", href: "/admin/users", icon: Users },
        ]
      : []),
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row">
      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between p-4 border-b bg-white">
        <div className="font-heading font-bold text-xl text-primary flex items-center gap-2">
          <Shield className="w-6 h-6" /> InsurAI
        </div>
        <Sheet open={isMobileOpen} onOpenChange={setIsMobileOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon">
              <Menu className="w-6 h-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[80%] max-w-[300px]">
            <div className="flex flex-col gap-6 mt-8">
              {navItems.map((item) => (
                <Link key={item.href} href={item.href} onClick={() => setIsMobileOpen(false)}>
                  <div
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                      location === item.href
                        ? "bg-primary text-primary-foreground font-medium"
                        : "text-muted-foreground hover:bg-muted"
                    }`}
                  >
                    <item.icon className="w-5 h-5" />
                    {item.label}
                  </div>
                </Link>
              ))}
              <div className="border-t pt-4 mt-auto">
                 <Button variant="ghost" className="w-full justify-start gap-3 text-destructive" onClick={() => logout()}>
                    <LogOut className="w-5 h-5" /> Logout
                 </Button>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 border-r bg-white h-screen sticky top-0 p-6">
        <div className="font-heading font-bold text-2xl text-primary flex items-center gap-2 mb-10">
          <Shield className="w-8 h-8" /> InsurAI
        </div>
        
        <nav className="flex flex-col gap-2 flex-1">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <div
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 cursor-pointer ${
                  location === item.href
                    ? "bg-primary text-primary-foreground font-medium shadow-md shadow-primary/20"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
              >
                <item.icon className="w-5 h-5" />
                {item.label}
              </div>
            </Link>
          ))}
        </nav>

        <div className="border-t pt-4 mt-4">
          <div className="flex items-center gap-3 mb-4 px-2">
            <Avatar>
              <AvatarImage src={user?.profileImageUrl || undefined} />
              <AvatarFallback>{user?.firstName?.[0] || "U"}</AvatarFallback>
            </Avatar>
            <div className="flex flex-col overflow-hidden">
               <span className="text-sm font-medium truncate">{user?.firstName || "User"}</span>
               <span className="text-xs text-muted-foreground capitalize">{role}</span>
            </div>
          </div>
          <Button variant="outline" className="w-full justify-start gap-3" onClick={() => logout()}>
            <LogOut className="w-4 h-4" /> Logout
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        <header className="h-16 border-b bg-white/50 backdrop-blur-sm sticky top-0 z-10 flex items-center justify-between px-6 md:px-10">
           <h1 className="font-heading font-bold text-xl capitalize text-foreground">
             {navItems.find(i => i.href === location)?.label || "Dashboard"}
           </h1>
           <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" className="relative">
                 <Bell className="w-5 h-5 text-muted-foreground" />
                 <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full"></span>
              </Button>
              <Link href="/voice-assistant">
                 <Button className="bg-gradient-to-r from-primary to-blue-600 shadow-lg shadow-primary/20 hover:shadow-xl transition-all">
                    <Mic className="w-4 h-4 mr-2" /> AI Assistant
                 </Button>
              </Link>
           </div>
        </header>
        <div className="p-6 md:p-10 max-w-7xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
}
