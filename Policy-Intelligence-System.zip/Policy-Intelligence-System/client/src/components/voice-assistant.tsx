import { useState, useRef, useEffect } from "react";
import { useVoiceRecorder, useVoiceStream } from "@/replit_integrations/audio";
import { Mic, MicOff, Volume2, Square, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card } from "@/components/ui/card";

export function VoiceAssistant({ conversationId }: { conversationId: number }) {
  const [transcript, setTranscript] = useState("");
  const [history, setHistory] = useState<{role: 'user' | 'assistant', text: string}[]>([]);
  const recorder = useVoiceRecorder();
  
  const scrollRef = useRef<HTMLDivElement>(null);

  const stream = useVoiceStream({
    onUserTranscript: (text) => {
       setHistory(prev => [...prev, { role: 'user', text }]);
    },
    onTranscript: (_, full) => setTranscript(full),
    onComplete: (fullText) => {
       setHistory(prev => [...prev, { role: 'assistant', text: fullText }]);
       setTranscript("");
    },
  });

  const handleMicClick = async () => {
    if (recorder.state === "recording") {
      const blob = await recorder.stopRecording();
      await stream.streamVoiceResponse(
        `/api/conversations/${conversationId}/messages`,
        blob
      );
    } else {
      await recorder.startRecording();
    }
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [history, transcript]);

  return (
    <Card className="flex flex-col h-[500px] shadow-xl overflow-hidden border-0 bg-white/80 backdrop-blur-md">
      <div className="p-4 border-b bg-primary/5 flex items-center justify-between">
         <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
            <span className="font-semibold text-primary">AI Policy Assistant</span>
         </div>
      </div>

      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        <div className="flex flex-col gap-4">
           {history.map((msg, idx) => (
             <motion.div 
               key={idx}
               initial={{ opacity: 0, y: 10 }}
               animate={{ opacity: 1, y: 0 }}
               className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
             >
               <div className={`
                 max-w-[80%] p-4 rounded-2xl text-sm leading-relaxed shadow-sm
                 ${msg.role === 'user' 
                   ? 'bg-primary text-primary-foreground rounded-br-none' 
                   : 'bg-white border text-foreground rounded-bl-none'}
               `}>
                 {msg.text}
               </div>
             </motion.div>
           ))}
           
           {transcript && (
             <motion.div 
               initial={{ opacity: 0 }} 
               animate={{ opacity: 1 }}
               className="flex justify-start"
             >
                <div className="max-w-[80%] p-4 rounded-2xl bg-white border text-foreground rounded-bl-none text-sm shadow-sm flex items-center gap-2">
                   <Loader2 className="w-3 h-3 animate-spin text-primary" />
                   {transcript}
                </div>
             </motion.div>
           )}
        </div>
      </ScrollArea>

      <div className="p-6 border-t bg-white">
        <div className="flex items-center justify-center gap-4">
          <button
             onClick={handleMicClick}
             className={`
                h-16 w-16 rounded-full flex items-center justify-center shadow-lg transition-all duration-300
                ${recorder.state === "recording" 
                  ? "bg-red-500 hover:bg-red-600 shadow-red-500/30 scale-110" 
                  : "bg-primary hover:bg-primary/90 shadow-primary/30 hover:scale-105"}
             `}
          >
             {recorder.state === "recording" ? (
                <Square className="w-6 h-6 text-white fill-current" />
             ) : (
                <Mic className="w-8 h-8 text-white" />
             )}
          </button>
        </div>
        <p className="text-center text-xs text-muted-foreground mt-4 font-medium">
           {recorder.state === "recording" ? "Listening..." : "Tap to speak"}
        </p>
      </div>
    </Card>
  );
}
