## Packages
framer-motion | Smooth animations and transitions
date-fns | Date formatting and manipulation
react-day-picker | Calendar component for scheduling
lucide-react | Icons (already in base, but emphasizing usage)
recharts | Charts for admin dashboard

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  heading: ["Outfit", "sans-serif"],
}
