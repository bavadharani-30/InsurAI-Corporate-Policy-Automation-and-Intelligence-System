import type { Express } from "express";
import type { Server } from "http";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { registerAudioRoutes } from "./replit_integrations/audio";
import { registerImageRoutes } from "./replit_integrations/image";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // === INTEGRATIONS ===
  await setupAuth(app);
  registerAuthRoutes(app);
  registerAudioRoutes(app);
  registerImageRoutes(app);

  // === APP ROUTES ===

  // Middleware to check if user has a profile, if not create a default one
  app.use(async (req, res, next) => {
    if (req.isAuthenticated() && (req.user as any)?.claims?.sub) {
      const userId = (req.user as any).claims.sub;
      const profile = await storage.getProfile(userId);
      if (!profile) {
        // Create default profile
        await storage.createProfile({
          userId,
          role: "customer", // Default role
        });
      }
    }
    next();
  });

  // --- Profiles ---
  app.get(api.profiles.get.path, async (req, res) => {
    const profile = await storage.getProfile(req.params.userId);
    if (!profile) return res.status(404).json({ message: "Profile not found" });
    res.json(profile);
  });

  app.put(api.profiles.update.path, async (req, res) => {
    try {
      // Ensure user can only update their own profile unless admin
      // simplified for MVP: allow if authenticated and matching ID
      const userId = req.params.userId;
      const currentUser = (req.user as any)?.claims?.sub;
      
      if (!req.isAuthenticated() || currentUser !== userId) {
         // Check if admin? For now just restrict to self
         return res.status(401).json({ message: "Unauthorized" });
      }

      const input = api.profiles.update.input.parse(req.body);
      const updated = await storage.updateProfile(userId, input);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get(api.profiles.list.path, async (req, res) => {
    // Admin check logic here...
    const users = await storage.getAllUsersWithProfiles();
    res.json(users);
  });

  // --- Agents ---
  app.get(api.agents.list.path, async (req, res) => {
    const agents = await storage.getAllAgents();
    res.json(agents);
  });

  // --- Plans ---
  app.get(api.plans.list.path, async (req, res) => {
    const plans = await storage.getPlans();
    res.json(plans);
  });

  app.get(api.plans.get.path, async (req, res) => {
    const plan = await storage.getPlan(Number(req.params.id));
    if (!plan) return res.status(404).json({ message: "Plan not found" });
    res.json(plan);
  });

  app.post(api.plans.create.path, async (req, res) => {
    // Admin check...
    try {
      const input = api.plans.create.input.parse(req.body);
      const plan = await storage.createPlan(input);
      res.status(201).json(plan);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.put(api.plans.update.path, async (req, res) => {
    // Admin check...
    try {
      const input = api.plans.update.input.parse(req.body);
      const plan = await storage.updatePlan(Number(req.params.id), input);
      res.json(plan);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.delete(api.plans.delete.path, async (req, res) => {
    // Admin check...
    await storage.deletePlan(Number(req.params.id));
    res.status(204).send();
  });

  // --- Appointments ---
  app.get(api.appointments.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    const userId = (req.user as any).claims.sub;
    
    // Determine role
    const profile = await storage.getProfile(userId);
    const role = (profile?.role as any) || "customer";

    const appointments = await storage.getAppointments(userId, role);
    res.json(appointments);
  });

  app.post(api.appointments.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    try {
      const input = api.appointments.create.input.parse(req.body);
      
      // Override customerId with current user if not provided or enforce it?
      // Usually customer books for themselves.
      const userId = (req.user as any).claims.sub;
      
      const appointment = await storage.createAppointment({
        ...input,
        customerId: userId // Enforce current user
      });

      // Notify Agent
      await storage.createNotification({
        userId: input.agentId,
        type: "new_booking",
        message: `New appointment booked for ${input.date} at ${input.time}`,
      });

      res.status(201).json(appointment);
    } catch (err) {
      console.error(err);
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.put(api.appointments.update.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    try {
      const input = api.appointments.update.input.parse(req.body);
      const updated = await storage.updateAppointment(Number(req.params.id), input);
      
      // Notify Customer if status changed
      if (input.status) {
        const appt = await storage.getAppointment(Number(req.params.id));
        if (appt) {
          await storage.createNotification({
            userId: appt.customerId,
            type: "appointment_update",
            message: `Your appointment status has been updated to ${input.status}`,
          });
        }
      }

      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  // --- Availability ---
  app.get(api.availability.list.path, async (req, res) => {
    const availability = await storage.getAvailability(req.params.agentId);
    res.json(availability);
  });

  app.post(api.availability.update.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    try {
      const userId = (req.user as any).claims.sub;
      const input = api.availability.update.input.parse(req.body);
      const availability = await storage.setAvailability(userId, input.availabilities);
      res.json(availability);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  // --- Notifications ---
  app.get(api.notifications.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    const userId = (req.user as any).claims.sub;
    const notifications = await storage.getNotifications(userId);
    res.json(notifications);
  });

  app.patch(api.notifications.markRead.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    const updated = await storage.markNotificationRead(Number(req.params.id));
    res.json(updated);
  });

  return httpServer;
}

// Seed function
async function seedData() {
  const plans = await storage.getPlans();
  if (plans.length === 0) {
    console.log("Seeding plans...");
    await storage.createPlan({
      name: "Basic Health",
      description: "Essential health coverage for individuals.",
      premium: 2999, // $29.99
      coverageAmount: 10000,
      category: "Health",
      active: true,
    });
    await storage.createPlan({
      name: "Premium Life",
      description: "Comprehensive life insurance with high coverage.",
      premium: 9999, // $99.99
      coverageAmount: 500000,
      category: "Life",
      active: true,
    });
    await storage.createPlan({
      name: "Corporate Starter",
      description: "Basic insurance package for small businesses.",
      premium: 19999, // $199.99
      coverageAmount: 100000,
      category: "Corporate",
      active: true,
    });
  }
}

// Run seed
seedData().catch(console.error);
