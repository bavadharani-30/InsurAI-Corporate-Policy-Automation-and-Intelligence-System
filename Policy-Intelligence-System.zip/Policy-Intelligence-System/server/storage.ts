import { db } from "./db";
import { 
  profiles, plans, agentAvailability, appointments, notifications,
  type Profile, type InsertProfile,
  type Plan, type InsertPlan,
  type AgentAvailability, type InsertAvailability,
  type Appointment, type InsertAppointment,
  type Notification,
  userRoles,
  appointmentStatus
} from "@shared/schema";
import { users, type User } from "@shared/models/auth";
import { eq, and, desc } from "drizzle-orm";

export interface IStorage {
  // Profiles
  getProfile(userId: string): Promise<Profile | undefined>;
  createProfile(profile: InsertProfile): Promise<Profile>;
  updateProfile(userId: string, updates: Partial<InsertProfile>): Promise<Profile>;
  
  // Users (Admin)
  getAllUsersWithProfiles(): Promise<{ user: User, profile: Profile | null }[]>;
  getAllAgents(): Promise<{ user: User, profile: Profile | null }[]>;

  // Plans
  getPlans(): Promise<Plan[]>;
  getPlan(id: number): Promise<Plan | undefined>;
  createPlan(plan: InsertPlan): Promise<Plan>;
  updatePlan(id: number, updates: Partial<InsertPlan>): Promise<Plan>;
  deletePlan(id: number): Promise<void>;

  // Availability
  getAvailability(agentId: string): Promise<AgentAvailability[]>;
  setAvailability(agentId: string, availabilities: Omit<InsertAvailability, "agentId">[]): Promise<AgentAvailability[]>;

  // Appointments
  getAppointments(userId: string, role: "customer" | "agent" | "admin"): Promise<(Appointment & { agent?: User, customer?: User, plan?: Plan })[]>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: number, updates: Partial<InsertAppointment>): Promise<Appointment>;
  getAppointment(id: number): Promise<Appointment | undefined>;

  // Notifications
  getNotifications(userId: string): Promise<Notification[]>;
  createNotification(notification: Omit<Notification, "id" | "createdAt" | "read">): Promise<Notification>;
  markNotificationRead(id: number): Promise<Notification>;
}

export class DatabaseStorage implements IStorage {
  // === PROFILES ===
  async getProfile(userId: string): Promise<Profile | undefined> {
    const [profile] = await db.select().from(profiles).where(eq(profiles.userId, userId));
    return profile;
  }

  async createProfile(profile: InsertProfile): Promise<Profile> {
    const [newProfile] = await db.insert(profiles).values(profile).returning();
    return newProfile;
  }

  async updateProfile(userId: string, updates: Partial<InsertProfile>): Promise<Profile> {
    const [updated] = await db.update(profiles)
      .set(updates)
      .where(eq(profiles.userId, userId))
      .returning();
    return updated;
  }

  async getAllUsersWithProfiles(): Promise<{ user: User, profile: Profile | null }[]> {
    const rows = await db.select({
      user: users,
      profile: profiles,
    })
    .from(users)
    .leftJoin(profiles, eq(users.id, profiles.userId));
    
    return rows;
  }

  async getAllAgents(): Promise<{ user: User, profile: Profile | null }[]> {
    const rows = await db.select({
      user: users,
      profile: profiles,
    })
    .from(users)
    .leftJoin(profiles, eq(users.id, profiles.userId))
    .where(eq(profiles.role, "agent"));
    
    return rows;
  }

  // === PLANS ===
  async getPlans(): Promise<Plan[]> {
    return await db.select().from(plans).orderBy(desc(plans.createdAt));
  }

  async getPlan(id: number): Promise<Plan | undefined> {
    const [plan] = await db.select().from(plans).where(eq(plans.id, id));
    return plan;
  }

  async createPlan(plan: InsertPlan): Promise<Plan> {
    const [newPlan] = await db.insert(plans).values(plan).returning();
    return newPlan;
  }

  async updatePlan(id: number, updates: Partial<InsertPlan>): Promise<Plan> {
    const [updated] = await db.update(plans).set(updates).where(eq(plans.id, id)).returning();
    return updated;
  }

  async deletePlan(id: number): Promise<void> {
    await db.delete(plans).where(eq(plans.id, id));
  }

  // === AVAILABILITY ===
  async getAvailability(agentId: string): Promise<AgentAvailability[]> {
    return await db.select().from(agentAvailability).where(eq(agentAvailability.agentId, agentId));
  }

  async setAvailability(agentId: string, availabilities: Omit<InsertAvailability, "agentId">[]): Promise<AgentAvailability[]> {
    // Transaction-like: delete existing and insert new
    await db.delete(agentAvailability).where(eq(agentAvailability.agentId, agentId));
    
    if (availabilities.length === 0) return [];

    const toInsert = availabilities.map(a => ({ ...a, agentId }));
    return await db.insert(agentAvailability).values(toInsert).returning();
  }

  // === APPOINTMENTS ===
  async getAppointments(userId: string, role: "customer" | "agent" | "admin"): Promise<(Appointment & { agent?: User, customer?: User, plan?: Plan })[]> {
    // Base query
    let query = db.select({
      appointment: appointments,
      agent: users, // joined as agent
      // We need to join users twice, once for agent, once for customer. 
      // Drizzle's query builder with explicit joins is better here.
    }).from(appointments);

    // This complex join is easier with the query builder if we had aliases, 
    // but standard Drizzle `select().from()` with leftJoins works.
    // Let's do a manual fetch with joins for now or simplified.
    // Actually, `query.leftJoin` works.

    // Let's optimize: fetch all appointments filtered by user
    let conditions = undefined;
    if (role === 'customer') {
      conditions = eq(appointments.customerId, userId);
    } else if (role === 'agent') {
      conditions = eq(appointments.agentId, userId);
    }
    // admin sees all

    const result = await db.select({
      appointment: appointments,
      plan: plans,
      // We can't easily alias the same table 'users' twice in a simple select object without 'aliasedTable'.
      // For simplicity, we'll just fetch the appointment + plan, and maybe fetch users separately or use raw sql if needed.
      // OR, simpler: just return the appointment and let frontend fetch user details if needed, 
      // BUT list view usually needs names.
      // Let's use aliased tables.
    })
    .from(appointments)
    .leftJoin(plans, eq(appointments.planId, plans.id))
    .where(conditions)
    .orderBy(desc(appointments.date), desc(appointments.time));

    // Now populate agent/customer names. Ideally we do this in SQL. 
    // For MVP/Lite, separate queries are fine given low volume.
    const populated = await Promise.all(result.map(async (row) => {
      const [agent] = await db.select().from(users).where(eq(users.id, row.appointment.agentId));
      const [customer] = await db.select().from(users).where(eq(users.id, row.appointment.customerId));
      return {
        ...row.appointment,
        plan: row.plan || undefined,
        agent,
        customer
      };
    }));

    return populated;
  }

  async createAppointment(appointment: InsertAppointment): Promise<Appointment> {
    const [newAppt] = await db.insert(appointments).values(appointment).returning();
    return newAppt;
  }

  async updateAppointment(id: number, updates: Partial<InsertAppointment>): Promise<Appointment> {
    const [updated] = await db.update(appointments).set(updates).where(eq(appointments.id, id)).returning();
    return updated;
  }

  async getAppointment(id: number): Promise<Appointment | undefined> {
    const [appt] = await db.select().from(appointments).where(eq(appointments.id, id));
    return appt;
  }

  // === NOTIFICATIONS ===
  async getNotifications(userId: string): Promise<Notification[]> {
    return await db.select().from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async createNotification(notification: Omit<Notification, "id" | "createdAt" | "read">): Promise<Notification> {
    const [newNotif] = await db.insert(notifications).values(notification).returning();
    return newNotif;
  }

  async markNotificationRead(id: number): Promise<Notification> {
    const [updated] = await db.update(notifications)
      .set({ read: true })
      .where(eq(notifications.id, id))
      .returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
